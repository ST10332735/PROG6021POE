using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        // Welcome the user to Recipe Manager
        Console.WriteLine("Welcome to Recipe Manager!");

        // Create a new Recipe object and populate it with user input
        Recipe recipe = new Recipe();
        recipe.GetIngredientsFromUser();
        recipe.GetStepsFromUser();

        // Display the recipe to the user
        recipe.DisplayRecipe();
    }
}

// The Recipe class represents a single recipe, with a list of ingredients and steps
class Recipe
{
    // List of ingredients for the recipe
    public List<string> Ingredients { get; set; }

    // List of steps for the recipe
    public List<string> Steps { get; set; }

    // Constructor for the Recipe class
    public Recipe()
    {
        Ingredients = new List<string>();
        Steps = new List<string>();
    }

    // Method to prompt the user for ingredients and add them to the Ingredients list
    public void GetIngredientsFromUser()
    {
        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter ingredient {i + 1}: ");
            string ingredient = Console.ReadLine();
            Ingredients.Add(ingredient);
        }
    }

    // Method to prompt the user for steps and add them to the Steps list
    public void GetStepsFromUser()
    {
        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i + 1}: ");
            string step = Console.ReadLine();
            Steps.Add(step);
        }
    }

    // Method to display the recipe to the user
    public void DisplayRecipe()
    {
        Console.WriteLine("\nRecipe Details:");
        Console.WriteLine("Ingredients:");
        foreach (string ingredient in Ingredients)
        {
            Console.WriteLine("- " + ingredient);
        }
        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + Steps[i]);
        }
    }
}